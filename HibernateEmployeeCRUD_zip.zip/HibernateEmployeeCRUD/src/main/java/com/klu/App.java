package com.klu;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class App {
    public static void main(String[] args) {
        // CREATE: Insert 10 employees
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Employee e1 = new Employee(101, "Amit Sharma", 75000.00, "Software Engineer");
        Employee e2 = new Employee(102, "Priya Singh", 85000.00, "Senior Developer");
        Employee e3 = new Employee(103, "Rahul Kumar", 60000.00, "Tester");
        Employee e4 = new Employee(104, "Sneha Patel", 95000.00, "Project Manager");
        Employee e5 = new Employee(105, "Vikram Rao", 55000.00, "HR Executive");
        Employee e6 = new Employee(106, "Ananya Mehta", 68000.00, "Data Analyst");
        Employee e7 = new Employee(107, "Rohan Gupta", 72000.00, "DevOps Engineer");
        Employee e8 = new Employee(108, "Kavya Nair", 80000.00, "UI/UX Designer");
        Employee e9 = new Employee(109, "Arjun Reddy", 65000.00, "System Administrator");
        Employee e10 = new Employee(110, "Neha Verma", 90000.00, "Team Lead");

        session.save(e1); session.save(e2); session.save(e3); session.save(e4);
        session.save(e5); session.save(e6); session.save(e7); session.save(e8);
        session.save(e9); session.save(e10);

        tx.commit();
        session.close();
        System.out.println("10 Employees Inserted Successfully");

        // READ: Fetch employee with ID 101
        session = HibernateUtil.getSessionFactory().openSession();
        Employee emp = session.get(Employee.class, 101);
        System.out.println("Employee Details: " + emp.getName() + 
                           ", Salary: " + emp.getSalary() + 
                           ", Designation: " + emp.getDesignation());
        session.close();

        // UPDATE: Update salary of employee 101
        session = HibernateUtil.getSessionFactory().openSession();
        tx = session.beginTransaction();
        emp.setSalary(82000.00);
        emp.setDesignation("Senior Software Engineer");
        session.update(emp);
        tx.commit();
        session.close();
        System.out.println("Employee Updated Successfully");

        // DELETE: Delete employee 110
        session = HibernateUtil.getSessionFactory().openSession();
        tx = session.beginTransaction();
        Employee empToDelete = session.get(Employee.class, 110);
        session.delete(empToDelete);
        tx.commit();
        session.close();
        System.out.println("Employee Deleted Successfully");
    }
}