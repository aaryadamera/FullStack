package com.klu;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class App {
    public static void main(String[] args) {
        // CLEAR OLD DATA FROM emp_details (safe even if table is empty)
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();
        session.createQuery("DELETE FROM Employee").executeUpdate();  // Matches entity name
        tx.commit();
        session.close();
        System.out.println("=== Old data cleared from emp_details table ===\n");

        // INSERT 10 EMPLOYEES
        session = HibernateUtil.getSessionFactory().openSession();
        tx = session.beginTransaction();

        Employee e1 = new Employee(101, "Priyanka", 75000.00, "Software Engineer");
        Employee e2 = new Employee(102, "Nivedita", 85000.00, "Senior Developer");
        Employee e3 = new Employee(103, "Veeha", 60000.00, "Tester");
        Employee e4 = new Employee(104, "Jai", 95000.00, "Project Manager");
        Employee e5 = new Employee(105, "Vikram", 55000.00, "HR Executive");
        Employee e6 = new Employee(106, "Tharun", 68000.00, "Data Analyst");
        Employee e7 = new Employee(107, "Rohan", 72000.00, "DevOps Engineer");
        Employee e8 = new Employee(108, "Kavya", 80000.00, "UI/UX Designer");
        Employee e9 = new Employee(109, "Ajith", 65000.00, "System Administrator");
        Employee e10 = new Employee(110, "Neha", 90000.00, "Team Lead");

        session.save(e1); session.save(e2); session.save(e3); session.save(e4);
        session.save(e5); session.save(e6); session.save(e7); session.save(e8);
        session.save(e9); session.save(e10);

        tx.commit();
        session.close();
        System.out.println("10 Employees Inserted into emp_details Successfully\n");

        // READ EXAMPLE
        session = HibernateUtil.getSessionFactory().openSession();
        Employee emp = session.get(Employee.class, 101);
        System.out.println("Sample Read → ID: 101, Name: " + emp.getName() +
                           ", Salary: " + emp.getSalary() +
                           ", Designation: " + emp.getDesignation());
        session.close();
    }
}