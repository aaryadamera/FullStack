package helloworld;
import java.util.*;
class vehicle {
	void move() {
		System.out.println("Vehicle is moving");
	}
}
class car extends vehicle{
	void drive() {
		System.out.println("I'm driving the car");
	}
}
class electriccar extends car{
	void charge() {
		System.out.println("Electric car should be chargeg to drive it");
	}
}
public class inheritance_vehicle_car_electriccar {
	public static void main(String[] args) {
		O o = new O();
		o.move();
		o.drive();
		o.charge();
	}
}
